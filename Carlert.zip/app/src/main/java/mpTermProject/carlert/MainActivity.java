package mpTermProject.carlert;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
public class MainActivity extends AppCompatActivity {
    RadioGroup color;
    RadioGroup shape;
    RadioButton red;
    RadioButton yellow;
    RadioButton green;
    RadioButton otherColor;
    RadioButton circle;
    RadioButton triangle;
    RadioButton car;
    RadioButton otherShape;
    RadioButton allColor;
    RadioButton allShape;
    Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        color = findViewById(R.id.radGroupColor);
        shape = findViewById(R.id.radGroupShape);
        red = findViewById(R.id.red);
        yellow = findViewById(R.id.yellow);
        green = findViewById(R.id.green);
        otherColor = findViewById(R.id.otherColor);
        otherShape = findViewById(R.id.otherShape);
        circle = findViewById(R.id.circle);
        car = findViewById(R.id.car);
        triangle = findViewById(R.id.triangle);
        allColor = findViewById(R.id.allColor);
        allShape = findViewById(R.id.allShape);
        btn = findViewById(R.id.btn);

        GridView gv = findViewById(R.id.mygrid);
        gv.setAdapter(new SetImageAdapter(this));

        btn.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                String msg = "";
                if(allColor.isChecked()){
                    msg+="all color";
                }
                if(red.isChecked()){
                    msg+="red";
                }
                if(yellow.isChecked()){
                    msg+="yellow";
                }
                if(green.isChecked()){
                    msg+="green";
                }
                if(otherColor.isChecked()){
                    msg+="other color";
                }
                int radioid=color.getCheckedRadioButtonId();
                if(allShape.isChecked())
                    msg="all shape "+msg;
                if(circle.isChecked())
                    msg="circle "+msg;
                if(triangle.isChecked())
                    msg="triangle "+msg;
                if(car.isChecked())
                    msg="car "+msg;
                if(otherShape.isChecked())
                    msg="other shape "+msg;
                Toast.makeText(getApplicationContext(),msg, Toast.LENGTH_LONG).show();

            }
        });
    }
}
